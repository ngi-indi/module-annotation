'use strict';

/**
 * relation-locale controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::relation-locale.relation-locale');
