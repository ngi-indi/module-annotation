'use strict';

module.exports = ({ strapi }) => {};
