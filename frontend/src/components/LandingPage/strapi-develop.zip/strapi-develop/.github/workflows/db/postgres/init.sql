CREATE SCHEMA myschema;
