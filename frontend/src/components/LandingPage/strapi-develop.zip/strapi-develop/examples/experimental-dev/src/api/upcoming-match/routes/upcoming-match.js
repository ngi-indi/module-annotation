'use strict';

/**
 * upcoming-match router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::upcoming-match.upcoming-match');
