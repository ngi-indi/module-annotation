---
title: Overview
tags:
  - experimental
  - providers
  - import
  - export
  - data-transfer
---

# Strapi Data File Providers

Strapi data file providers transfer data to or from a [Strapi Data File](./01-file-structure.md).

The files are optionally compressed and/or encrypted using a given key (password).
