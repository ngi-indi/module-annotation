---
title: Introduction
tags:
  - admin
---

# Admin

This section is an overview of all the features related to admin:

```mdx-code-block
import DocCardList from '@theme/DocCardList';
import { useCurrentSidebarCategory } from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items} />
```
