'use strict';

module.exports = {
  test: require('./test'),
};
