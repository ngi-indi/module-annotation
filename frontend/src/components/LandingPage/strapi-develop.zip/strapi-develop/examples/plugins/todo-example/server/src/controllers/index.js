'use strict';

module.exports = {
  tasks: require('./tasks'),
};
