import pluginId from '../pluginId';

const getTrad = (id) => `${pluginId}.${id}`;

export default getTrad;
