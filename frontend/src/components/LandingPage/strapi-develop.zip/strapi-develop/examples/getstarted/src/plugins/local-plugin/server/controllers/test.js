module.exports = {
  findOne(ctx) {
    ctx.body = {};
  },
  find(ctx) {
    ctx.body = [];
  },
};
