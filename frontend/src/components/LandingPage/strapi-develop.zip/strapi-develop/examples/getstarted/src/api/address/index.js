module.exports = {
  register() {
    // console.log('Address API register');
  },
  bootstrap() {
    // console.log('Address API bootstrap');
  },
};
