'use strict';

module.exports = {
  preset: '../../../jest-preset.unit.js',
  displayName: 'Github action check-pr-status',
};
