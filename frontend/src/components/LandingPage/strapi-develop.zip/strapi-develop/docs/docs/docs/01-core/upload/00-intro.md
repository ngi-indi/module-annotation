---
title: Introduction
slug: /upload
tags:
  - upload
---

# Content Manager

This section is an overview of all the features related to the Upload core plugin:

```mdx-code-block
import DocCardList from '@theme/DocCardList';
import { useCurrentSidebarCategory } from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items} />
```
