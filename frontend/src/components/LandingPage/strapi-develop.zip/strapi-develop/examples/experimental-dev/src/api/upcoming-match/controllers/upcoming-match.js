'use strict';

/**
 * upcoming-match controller
 */

const { createCoreController } = require('@strapi/strapi').factories;

module.exports = createCoreController('api::upcoming-match.upcoming-match');
