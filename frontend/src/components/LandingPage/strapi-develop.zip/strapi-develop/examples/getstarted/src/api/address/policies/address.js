module.exports = (policyCtx, config, { strapi }) => {
  return true;
};
