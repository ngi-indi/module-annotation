export default 'IMAGE_MOCK';
