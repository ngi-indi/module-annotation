'use strict';

const task = require('./task');

module.exports = {
  task: { schema: task },
};
