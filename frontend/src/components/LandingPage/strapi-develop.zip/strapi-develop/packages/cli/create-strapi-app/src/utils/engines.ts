export const engines = {
  node: '>=18.0.0 <=20.x.x',
  npm: '>=6.0.0',
};
