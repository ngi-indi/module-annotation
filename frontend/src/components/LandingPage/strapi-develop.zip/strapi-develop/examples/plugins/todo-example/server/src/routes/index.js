'use strict';

module.exports = {
  admin: require('./admin'),
};
