module.exports = (plugin) => {
  return plugin;
};
