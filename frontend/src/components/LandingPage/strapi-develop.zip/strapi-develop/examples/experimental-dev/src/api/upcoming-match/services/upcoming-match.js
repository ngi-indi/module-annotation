'use strict';

/**
 * upcoming-match service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::upcoming-match.upcoming-match');
