'use strict';

/**
 * relation-locale router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::relation-locale.relation-locale');
