module.exports = {
  rest: {
    defaultLimit: 25,
    maxLimit: 30,
    withCount: true,
  },
};
