'use strict';

module.exports = {
  preset: '../../../jest-preset.unit.js',
  displayName: 'Cloud CLI',
};
