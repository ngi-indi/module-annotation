'use strict';

/**
 * relation-locale service
 */

const { createCoreService } = require('@strapi/strapi').factories;

module.exports = createCoreService('api::relation-locale.relation-locale');
