# Cloud CLI

This package includes the `cloud` CLI to manage Strapi projects on the cloud.
