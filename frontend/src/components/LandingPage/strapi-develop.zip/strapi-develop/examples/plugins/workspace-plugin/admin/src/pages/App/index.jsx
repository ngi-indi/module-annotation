const App = () => {
  return 'I am a workspace plugin, imported via node_modules.';
};

export default App;
